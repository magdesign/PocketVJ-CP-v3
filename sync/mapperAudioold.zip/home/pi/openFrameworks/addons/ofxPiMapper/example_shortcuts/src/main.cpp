#include "ofMain.h"
#include "ofApp.h"

int main(){
	ofSetupOpenGL(800, 450, OF_WINDOW);
	ofRunApp(new ofApp());
}
