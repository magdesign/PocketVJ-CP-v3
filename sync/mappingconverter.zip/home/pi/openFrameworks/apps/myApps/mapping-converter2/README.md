# mapping-converter2
Convert .svg exports from MadMapper and Mapio to ofxPiMapper

For compiling make sure you cloned: https://github.com/NickHardeman/ofxSvgLoader to addons.
Then clone this to apps/myapps and compile.

Specially designed for PocketVJ/Rpi/ofxPiMapper.

You may use this software for free for your private/student projects.

You have to include the AUTHORS.md file.

Its also nice and motivating when you send me infos about the project you are using it.

If you want to use it commercially, please inform me by writing an email to: info@magdesign.ch
