#pragma once

namespace ofx {
namespace piMapper {

struct EditorType {
	enum {
		TEXTURE, PROJECTION
	};
};

} // namespace piMapper
} // namespace ofx