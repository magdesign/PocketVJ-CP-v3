#include "ofMain.h"
#include "ofApp.h"

int main(){
	ofSetupOpenGL(1280, 800, OF_WINDOW);
	ofRunApp(new ofApp());
}
